# SmartMoving (Fabric) – Stamina Template (1.21.6 ~ 1.21.8)

- **Run + Sneak + C** 키 조합을 누르면 "슬라이딩 상태"로 간주하고 스태미너가 감소합니다.
- 그렇지 않을 땐 스태미너가 서서히 회복됩니다.
- HUD 오른쪽 상단(예: 좌측 상단 10,10)에 **STAMINA: 0~100** 텍스트가 그려집니다.
- **Fabric API 없이** 믹신만으로 구현되므로 바로 빌드/실행됩니다.

## 빌드
- Java 21 설치
- `./gradlew build` → `build/libs/smartmoving-fabric-stamina-0.2.0-remapped.jar` 생성

## GitHub Actions
- 이 폴더를 새 GitHub 저장소로 푸시하면 자동으로 빌드 + Artifact 업로드됩니다.

## 키 조합
- 바닐라 **달리기**(Sprint) + **웅크리기**(Sneak) + **C 키**를 동시에 누르면 소모.
- C 키는 신규 바인딩 없이 GLFW로 직접 감지합니다.

## 주의
- 멀티 서버 동기화/서버 권위는 포함하지 않은 **클라이언트 샘플**입니다.
- 실사용에선 패킷/서버 검증/히트박스 조정 등을 추가하세요.

템플릿 생성: 2025-09-30
