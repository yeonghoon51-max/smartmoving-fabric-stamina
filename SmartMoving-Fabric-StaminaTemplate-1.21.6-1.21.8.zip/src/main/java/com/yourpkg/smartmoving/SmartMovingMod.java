
package com.yourpkg.smartmoving;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmartMovingMod implements ModInitializer {
    public static final String MOD_ID = "smartmoving";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOG.info("SmartMoving (Fabric) Stamina Template loaded! (1.21.6~1.21.8)");
    }
}
