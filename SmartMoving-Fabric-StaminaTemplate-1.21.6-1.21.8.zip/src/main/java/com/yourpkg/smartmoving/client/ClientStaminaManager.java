
package com.yourpkg.smartmoving.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class ClientStaminaManager {
    private static float stamina = 100.0f;
    private static boolean sliding = false;

    // Tunables
    private static final float DRAIN_PER_TICK = 0.25f;   // about 5 per second @20tps
    private static final float REGEN_PER_TICK = 0.15f;   // about 3 per second
    private static final int    KEY_C = GLFW.GLFW_KEY_C;

    public static void clientTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.isPaused()) return;

        KeyBinding sprint = mc.options.sprintKey;
        KeyBinding sneak  = mc.options.sneakKey;
        boolean cDown = isKeyDown(KEY_C);

        sliding = sprint.isPressed() && sneak.isPressed() && cDown;

        if (sliding) {
            stamina = Math.max(0f, stamina - DRAIN_PER_TICK);
        } else {
            stamina = Math.min(100f, stamina + REGEN_PER_TICK);
        }
    }

    public static boolean isSliding() { return sliding; }
    public static int staminaPercent() { return Math.round(stamina); }

    private static boolean isKeyDown(int key) {
        long handle = MinecraftClient.getInstance().getWindow().getHandle();
        return org.lwjgl.glfw.GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
    }
}
