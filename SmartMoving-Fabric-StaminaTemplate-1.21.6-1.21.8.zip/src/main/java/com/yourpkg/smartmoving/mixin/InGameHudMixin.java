
package com.yourpkg.smartmoving.mixin;

import com.yourpkg.smartmoving.client.ClientStaminaManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void smartmoving$render(DrawContext ctx, float tickDelta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;

        String s = "STAMINA: " + ClientStaminaManager.staminaPercent() +
                   (ClientStaminaManager.isSliding() ? " (SLIDING)" : "");
        // x=10, y=10
        ctx.drawText(mc.textRenderer, Text.literal(s), 10, 10, 0xFFFFFF, true);
    }
}
